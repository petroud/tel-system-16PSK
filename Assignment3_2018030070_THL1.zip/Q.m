function y = Q(x)
% y=Q(x)

y = 0.5  * erfc( x /sqrt(2) );


